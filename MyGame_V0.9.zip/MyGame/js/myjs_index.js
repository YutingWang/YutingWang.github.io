$(".howToPlay").click(function(){
	$("#howToPlay").fadeIn(800);
	//$("#howToPlay").css("display", "block");

});
$("#howToPlay").click(function(){
	$("#howToPlay").fadeOut(200);
	//$("#howToPlay").css("display", "none");
});

$(".about").click(function(){
	$("#about").fadeIn(800);
	//$("#howToPlay").css("display", "block");

});
$("#about").click(function(){
	$("#about").fadeOut(200);
	//$("#howToPlay").css("display", "none");
});